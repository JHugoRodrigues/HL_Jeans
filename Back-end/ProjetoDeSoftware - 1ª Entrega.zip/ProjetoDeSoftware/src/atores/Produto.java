package atores;

public class Produto {

	String nome;
	int qtdEstoque;
	double preco;
	
	public Produto(String nome, int qtdEstoque, double preco) {
		this.nome = nome;
		this.qtdEstoque = qtdEstoque;
		this.preco = preco;
	}

	 public boolean verificarDisponibilidade(int qtdPedido) {
		 return this.qtdEstoque >= qtdPedido;
	    }

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getQtdEstoque() {
		return qtdEstoque;
	}

	public void setQtdEstoque(int qtdEstoque) {
		this.qtdEstoque = qtdEstoque;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
}
