package atores;

public class Administrador extends Usuario {
	
	private String cargo;
	
	public Administrador(String nome, String email, String senha, String cargo) {
		super(nome, email, senha);
    	this.cargo = cargo;
}

	public void cadastrarProduto(String nome, String descricao, double preco, int quantidade) {
		System.out.println("Produto '" + nome + "' cadastrado com sucesso pelo admin " + this.nome);
}

    public void modificarEstoque(Produto produto, int novaQtd) {
        System.out.println("Estoque do produto '" + produto.getNome() + "' alterado para " + novaQtd);
        produto.setQtdEstoque(novaQtd);
}

//Getters e Setters
	public String getCargo() {
		return cargo;
}

	public void setCargo(String cargo) {
		this.cargo = cargo;
}
}
